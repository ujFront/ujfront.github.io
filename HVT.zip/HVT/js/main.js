// js/main.js
let currentConfig = null,
    sessionData = {},
    sessionStage = localStorage.getItem("sessionStage");

// V0–V17 grades
const vGrades = Array.from({ length: 18 }, (_, i) => "V" + i);

// Sample placeholders (replace with real API calls)
const sampleClasses = ["Class A", "Class B", "Class C"];
const sampleScoringSystems = ["System 1", "System 2"];

// DOM shortcuts
const $ = (id) => document.getElementById(id);

function init() {
    // Populate config dropdowns
    populateDropdown("classSelect", sampleClasses);
    populateDropdown("scoringSelect", sampleScoringSystems);

    // If there's a stored config, allow Continue
    if (localStorage.sessionConfig) {
        $("continueSessionBtn").disabled = false;
    }

    // Attach event listeners
    $("newSessionBtn").onclick = newSession;
    $("continueSessionBtn").onclick = continueSession;
    $("loadSavedBtn").onclick = showSavedList;
    $("loadSessionConfirmBtn").onclick = loadSavedSession;
    $("confirmConfigBtn").onclick = confirmConfig;
    $("saveScoresBtn").onclick = saveScores;
    $("btnReset").onclick = resetSession;
}

function populateDropdown(id, items) {
    const sel = $(id);
    sel.innerHTML = "";
    items.forEach((i) => {
        const opt = document.createElement("option");
        opt.value = i;
        opt.textContent = i;
        sel.appendChild(opt);
    });
}

function newSession() {
    localStorage.removeItem("sessionConfig");
    localStorage.removeItem("sessionData");
    localStorage.sessionStage = "config";
    showConfig();
}

function continueSession() {
    const cfg = JSON.parse(localStorage.sessionConfig || "null");
    if (!cfg) return alert("No session to continue.");
    currentConfig = cfg;
    sessionStage = localStorage.sessionStage;
    if (sessionStage === "config") showConfig();
    else showScoring(cfg.climbers);
}

function showSavedList() {
    api.getSavedSessions().then((sheets) => {
        populateDropdown("savedSessionSelect", sheets);
        $("savedSessionContainer").classList.remove("d-none");
    });
}

function loadSavedSession() {
    const name = $("savedSessionSelect").value;
    api.loadSession(name)
        .then((resp) => {
            if (resp.status === "success") {
                continueSession(); // now reload into your scoring or config stage
            } else {
                alert("Failed to load session");
            }
        })
        .catch((err) => alert("Error loading: " + err));
}

function confirmConfig() {
    const cls = $("classSelect").value,
        sys = $("scoringSelect").value;
    api.getConfig(cls, sys)
        .then((cfg) => {
            currentConfig = cfg;
            localStorage.sessionConfig = JSON.stringify(cfg);
            localStorage.sessionStage = "scoring";
            showScoring(cfg.climbers);
        })
        .catch((err) => alert(err.error || err));
}

function showConfig() {
    $("sessionChoice").classList.add("d-none");
    $("configSection").classList.remove("d-none");
}

function showScoring(climbers) {
    $("sessionChoice").classList.add("d-none");
    $("configSection").classList.add("d-none");
    $("scoringSection").classList.remove("d-none");
    generateTable(climbers);
}

function generateTable(climbers) {
    // reset data
    sessionData = {};
    let html =
        `<table class="table table-bordered"><thead><tr><th>Student</th>` +
        vGrades.map((g) => `<th>${g}</th>`).join("") +
        `</tr></thead><tbody>`;
    climbers.sort().forEach((st) => {
        sessionData[st] = {};
        html +=
            `<tr data-student="${st}"><td>${st}</td>` +
            vGrades
                .map((g) => {
                    sessionData[st][g] = 0;
                    return `<td>
               <div class="input-group">
                 <button class="btn btn-sm btn-outline-secondary btn-decrement" data-grade="${g}">−</button>
                 <span class="form-control text-center count-value" data-grade="${g}">0</span>
                 <button class="btn btn-sm btn-outline-secondary btn-increment" data-grade="${g}">+</button>
               </div>
             </td>`;
                })
                .join("") +
            `</tr>`;
    });
    html += `</tbody></table>`;
    $("scoringTableContainer").innerHTML = html;

    // attach +/- listeners
    $("scoringTableContainer").addEventListener("click", (e) => {
        const btn = e.target;
        if (!btn.dataset.grade) return;
        const tr = btn.closest("tr"),
            st = tr.dataset.student,
            g = btn.dataset.grade,
            span = tr.querySelector(`span[data-grade="${g}"]`);
        let v = sessionData[st][g];
        v = btn.classList.contains("btn-increment")
            ? v + 1
            : Math.max(0, v - 1);
        sessionData[st][g] = v;
        span.textContent = v;
    });
}

function saveScores() {
    console.log("Saving:", sessionData);
    alert("Scores saved (demo).");
}

function resetSession() {
    const name = prompt("Backup sheet name:");
    if (name)
        api.moveData(name)
            .then(() => {
                localStorage.clear();
                location.reload();
            })
            .catch(console.error);
}

// Initialize on load
document.addEventListener("DOMContentLoaded", init);
